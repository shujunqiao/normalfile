﻿#pragma once
//sudoku.h///
//头文件

void sudoku(char array[9][9]); //解数独游戏函数。
void Conversion_char_int(char a[9][9],int p[9][9]); //转换函数，讲字符型数组 转化成整形数组，'.'变为0。
bool Inspection(int sudo[9][9]); //检查该题目是否合法。int Blank_number(int sudo[9][9]); //计算所给数独中待填入的空白数

typedef struct node //代表每个待填空格属性，包括对应的位置，以及可以取得值。
{ 
	int col; int row; int value[10];
}Node; //带有typedef 字样的结构体，在申请结构体变量的时候， Node 可以代替 struct node。

void Initialization_col_row(int sudo[9][9],Node * node_sudo); //确定Node结构体重每一个元素的 col 和row 的值。
int Find_value(int sudo[9][9],Node * node_sudo); //找该空格可能的解，并试着求第一个解。
void Solving(int sudo[9][9],int num_of_empty,Node* node_sudo); //解数独问题
void Print_sudo(int sudo[9][9]); //输出求得的数独的解。
